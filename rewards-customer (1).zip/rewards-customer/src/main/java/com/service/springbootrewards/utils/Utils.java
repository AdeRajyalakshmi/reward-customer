package com.service.springbootrewards.utils;

public interface Utils {

	//public final abstract REWARD_PERCENTAGE;
}
