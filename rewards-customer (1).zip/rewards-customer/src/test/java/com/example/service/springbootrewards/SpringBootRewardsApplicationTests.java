package com.example.service.springbootrewards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRewardsApplicationTests {

	@Test
	void contextLoads() {
	}

}
